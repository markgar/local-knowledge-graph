---
title: Receipt details
date: '2026-04-22'
---

# Receipt details

Recorded: 2026-04-22.

From: Jamie
To: Rina
Sent: 2026-04-22
Subject: Receipt details
Message-ID: <m-892ceeb8dabaecfaeab3@work.example>

Jamie sent Rina the receipt for the office equipment delivery on April 22. Order 4b999031 contains 40 cable labels and 4 replacement adapters. The packing slip lists the quantities separately from the invoice total.

The supplier combined two boxes onto one tracking entry. The receipt copy is useful for reconciling the statement, but the tracking page no longer shows the individual box weights.

The finance export uses an approval column for the expense workflow. The office delivery entry is grouped with facilities purchases.
